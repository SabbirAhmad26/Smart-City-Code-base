import numpy as np
eps1 = 1.4 * (0.5 - np.random.rand())  # [-0.2, 0.2]
eps2 = 1 * (0.5 - np.random.rand())  # [-0.02, 0.02]
eps3 = 1 * (0.5 - np.random.rand())  # [-0.01, 0.01]
eps4 = 1.4 * (0.5 - np.random.rand())  # [-0.2, 0.2]
sigma1 = 1 + 0.2 * (0.5 - np.random.rand())  # [0.9, 1.1]
sigma2 = 1 + 0.2 * (0.5 - np.random.rand())  # [0.9, 1.1]


